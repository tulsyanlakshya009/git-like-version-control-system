package utils;

import java.io.File;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;

public class Clone {
    public void runClone(String[] args) {
        if (args.length < 2 || !args[0].equals("clone")) {
            System.out.println("Usage: clone <repository-url>");
            return;
        }
        
        String repoURL = args[1];
        String targetDir = args[2];
        try {
            Git.cloneRepository().setURI(repoURL).setDirectory(new File(targetDir)).call();
        } catch (GitAPIException e) {
            throw new RuntimeException(e);
        }
    }
}
