package utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

public class LsTree {
    public void runLsTree(String[] args) {
        if (args.length < 3 || !args[0].equals("ls-tree") || !args[1].equals("--name-only")) {
            System.out.println("Usage: ls-tree --name-only <tree-sha1>");
            return;
        }
        
        try{
            String treeHash = args[2];
            String filePath = getFilePath(treeHash);
            byte[] data = Files.readAllBytes(new File(filePath).toPath());
            String decompressedData = inflateData(data);
            String[] splitPermissionsAndFiles = decompressedData.split("\0");
            for (int i =1; i<splitPermissionsAndFiles.length; i++){
                int start = splitPermissionsAndFiles[i].indexOf(' ');
                if (start != -1) {
                    String fileName = splitPermissionsAndFiles[i].substring(start + 1);
                    System.out.println(fileName);
                }
            }
        } catch (DataFormatException e) {
            throw new RuntimeException(e);
        } catch (NullPointerException e) {
            throw new RuntimeException("Tree object not found: " , e);
        } catch (IOException e) {
            throw new RuntimeException("Error reading tree object: " + e);
        }
        // Actual implementation would involve reading the tree object and printing its contents
    }
    
    private String getFilePath(String objectHash) {
        String objectFolder = objectHash.substring(0, 2);
        String objectFile = objectHash.substring(2);
        return ".git/objects/" + objectFolder + "/" + objectFile;
    }


    private String inflateData(byte[] data) throws DataFormatException {
        // Decompress the data using zlib
        Inflater inflater = new Inflater();
        inflater.setInput(data);
        // Create a ByteArrayOutputStream to hold the decompressed data
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
        byte[] buffer = new byte[1024];
        while (!inflater.finished()) {
            int count = inflater.inflate(buffer);
            outputStream.write(buffer, 0, count);
        }
        // Ensure the inflater is properly ended
        inflater.end();
        return outputStream.toString(java.nio.charset.StandardCharsets.UTF_8);
    }
}
