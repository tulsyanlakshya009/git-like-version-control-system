package utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.zip.DeflaterOutputStream;

public class WriteTree {
    public String runWriteTree(File dir) throws IOException{
        File[] files = dir.listFiles((d, name) -> !name.equals(".git"));
        if (files == null) return null;
        Arrays.sort(files, Comparator.comparing(File::getName)); // Sort!
        ByteArrayOutputStream treeContent = new ByteArrayOutputStream();

        for (File file : files) {
            String mode;
            String sha;
            String name = file.getName();

            if (file.isDirectory()) {
                mode = "40000";
                sha = runWriteTree(file);
            } else {
                byte[] content = Files.readAllBytes(file.toPath());
                String header = "blob " + content.length + "\0";
                byte[] blob = concatenate(header.getBytes(StandardCharsets.UTF_8), content);
                sha = computeSHA1(blob);

                String dirName = ".git/objects/" + sha.substring(0, 2);
                String fileName = sha.substring(2);
                File objectFile = new File(dirName + "/" + fileName);
                if (!objectFile.exists()) {
                    new File(dirName).mkdirs();
                    try (FileOutputStream fos = new FileOutputStream(objectFile);
                        DeflaterOutputStream dos = new DeflaterOutputStream(fos)) {
                        dos.write(blob);
                    }
                }
                mode = "100644";
            }

            treeContent.write((mode + " " + name).getBytes(StandardCharsets.UTF_8));
            treeContent.write(0);
            treeContent.write(hexToBytes(sha));
        }

        byte[] raw = treeContent.toByteArray();
        String treeHeader = "tree " + raw.length + "\0";
        byte[] fullTree = concatenate(treeHeader.getBytes(StandardCharsets.UTF_8), raw);
        String treeSha = computeSHA1(fullTree);

        String treeDir = ".git/objects/" + treeSha.substring(0, 2);
        String treeFile = treeSha.substring(2);
        new File(treeDir).mkdirs();
        try (FileOutputStream fos = new FileOutputStream(treeDir + "/" + treeFile);
            DeflaterOutputStream dos = new DeflaterOutputStream(fos)) {
            dos.write(fullTree);
        }

        return treeSha;
    }

    private static byte[] hexToBytes(String hex) {
        byte[] bytes = new byte[hex.length() / 2];
        for (int i = 0; i < hex.length(); i += 2) {
            bytes[i / 2] = (byte) Integer.parseInt(hex.substring(i, i + 2), 16);
        }
        return bytes;
    }

    private static byte[] concatenate(byte[] a, byte[] b) {
        byte[] result = new byte[a.length + b.length];
        System.arraycopy(a, 0, result, 0, a.length);
        System.arraycopy(b, 0, result, a.length, b.length);
        return result;
    }

    private static String computeSHA1(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] hash = md.digest(data);
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-1 algorithm not found", e);
        }
    }
}
