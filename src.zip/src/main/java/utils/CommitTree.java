package utils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.DeflaterOutputStream;

public class CommitTree {
    public void runCommitTree(String[] args) {
        if (args.length < 3 || !args[0].equals("commit-tree") || args[1].equals("-help")) {
            System.out.println("Usage: commit-tree -p <object-hash>");
            return;
        }

        String treeSha = args[1];
            List<String> parentShas = new ArrayList<>();
            for (int i = 2; i < args.length - 1; i++) {
                if (args[i].equals("-p")) {
                    parentShas.add(args[i + 1]);
                }
            }
            String commitMessage = args[args.length - 1];

            String authorName = "Lakshya Tulsyan";
            String authorEmail = "tulsyanlakshya009@gmail.com";
            String committerName = "test committer";
            String committerEmail = "testcommitter@xxx.com";
            long timestamp = System.currentTimeMillis() / 1000;

            String parentCommitShas = String.join(" ", parentShas);
            String commitContent = String.format("tree %s\n", treeSha);
            if (!parentCommitShas.isEmpty()) {
                commitContent += String.format("parent %s\n", parentCommitShas);
            }
            commitContent += String.format("author %s <%s> %d +0000\n", authorName, authorEmail, timestamp);
            commitContent += String.format("committer %s <%s> %d +0000\n", committerName, committerEmail, timestamp);
            commitContent += "\n" + commitMessage + "\n";

            byte[] commitBytes = commitContent.getBytes(StandardCharsets.UTF_8);
            byte[] header = ("commit " + commitBytes.length + "\0").getBytes(StandardCharsets.UTF_8);
            byte[] commitObject = concatArr(header, commitBytes);
            String commitHash = computeHash(commitObject);
            writeGitObject(commitHash, commitObject);
            System.out.println(commitHash);
    }

    private static byte[] concatArr(byte[] arr1, byte[] arr2) {
        byte[] arr = new byte[arr1.length + arr2.length];
        System.arraycopy(arr1, 0, arr, 0, arr1.length);
        System.arraycopy(arr2, 0, arr, arr1.length, arr2.length);
        return arr;
    }

    private static String computeHash(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] hash = md.digest(data);
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-1 algorithm not found", e);
        }
    }

    private static void writeGitObject(String treeHash, byte[] treeObject) {
        File objectDir = new File(".git/objects/" + treeHash.substring(0, 2));
        if (!objectDir.exists())
        objectDir.mkdirs();
        File objectFile = new File(objectDir, treeHash.substring(2));
        if (!objectFile.exists()) {
            try (FileOutputStream fileOutputStream = new FileOutputStream(objectFile);
                BufferedOutputStream outputStream = new BufferedOutputStream(fileOutputStream);
                DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(outputStream)) {
                deflaterOutputStream.write(treeObject);
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
